/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dominio;

import javax.accessibility.AccessibleContext;

/**
 *
 * @author maril
 */
public class Professor {

    private int matricula;
    private String nome;
    private String formacao;
    private String tempo;
    private String livro;
    private String capLivro;
    private String revistaInternacional;
    private String revistaNacional;
    private String trabPublicado;
    private String gruposPesquisa;
    private String eventExterior;
    private String eventPais;
    private String coorientacaoDout;
    private String orientMestrado;
    private String coorientacaoMestrado;
    private String prodFilmes;
    private String campeonatos;
    private String elabSoftware;
    private String orientacaoBolsista;
    private String bancaExameDoutorado;
    private String traducaoArtigo;
    private String bancaExameMestrado;
    private String orientacaoDoutorado;
    private String bancaExame;
    private String bancaExameSelecao;
    private String coordProjetos;
    private String posDoutorado;
    private String premios;
    private String tradLivro;
    private String partOrg;

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }


    public String getTempo() {
        return tempo;
    }

    public void setTempo(String tempo) {
        this.tempo = tempo;
    }

    public String getFormacao() {
        return formacao;
    }

    public void setFormacao(String formacao) {
        this.formacao = formacao;
    }

    public String getLivro() {
        return livro;
    }

    public void setLivro(String livro) {
        this.livro = livro;
    }

    public String getCapLivro() {
        return capLivro;
    }

    public void setCapLivro(String capLivro) {
        this.capLivro = capLivro;
    }

    public String getRevistaInternacional() {
        return revistaInternacional;
    }

    public void setRevistaInternacional(String revistaInternacional) {
        this.revistaInternacional = revistaInternacional;
    }

    public String getRevistaNacional() {
        return revistaNacional;
    }

    public void setRevistaNacional(String revistaNacional) {
        this.revistaNacional = revistaNacional;
    }

    public String getTrabPublicado() {
        return trabPublicado;
    }

    public void setTrabPublicado(String trabPublicado) {
        this.trabPublicado = trabPublicado;
    }

    public String getGruposPesquisa() {
        return gruposPesquisa;
    }

    public void setGruposPesquisa(String gruposPesquisa) {
        this.gruposPesquisa = gruposPesquisa;
    }

    public String getEventExterior() {
        return eventExterior;
    }

    public void setEventExterior(String eventExterior) {
        this.eventExterior = eventExterior;
    }

    public String getEventPais() {
        return eventPais;
    }

    public void setEventPais(String eventPais) {
        this.eventPais = eventPais;
    }

    public String getCoorientacaoDout() {
        return coorientacaoDout;
    }

    public void setCoorientacaoDout(String coorientacaoDout) {
        this.coorientacaoDout = coorientacaoDout;
    }

    public String getOrientMestrado() {
        return orientMestrado;
    }

    public void setOrientMestrado(String orientMestrado) {
        this.orientMestrado = orientMestrado;
    }

    public String getCoorientacaoMestrado() {
        return coorientacaoMestrado;
    }

    public void setCoorientacaoMestrado(String coorientacaoMestrado) {
        this.coorientacaoMestrado = coorientacaoMestrado;
    }

    public String getProdFilmes() {
        return prodFilmes;
    }

    public void setProdFilmes(String prodFilmes) {
        this.prodFilmes = prodFilmes;
    }

    public String getCampeonatos() {
        return campeonatos;
    }

    public void setCampeonatos(String campeonatos) {
        this.campeonatos = campeonatos;
    }

    public String getElabSoftware() {
        return elabSoftware;
    }

    public void setElabSoftware(String elabSoftware) {
        this.elabSoftware = elabSoftware;
    }

    public String getOrientacaoBolsista() {
        return orientacaoBolsista;
    }

    public void setOrientacaoBolsista(String orientacaoBolsista) {
        this.orientacaoBolsista = orientacaoBolsista;
    }

    public String getBancaExameDoutorado() {
        return bancaExameDoutorado;
    }

    public void setBancaExameDoutorado(String bancaExameDoutorado) {
        this.bancaExameDoutorado = bancaExameDoutorado;
    }

    public String getTraducaoArtigo() {
        return traducaoArtigo;
    }

    public void setTraducaoArtigo(String traducaoArtigo) {
        this.traducaoArtigo = traducaoArtigo;
    }

    public String getBancaExameMestrado() {
        return bancaExameMestrado;
    }

    public void setBancaExameMestrado(String bancaExameMestrado) {
        this.bancaExameMestrado = bancaExameMestrado;
    }

    public String getOrientacaoDoutorado() {
        return orientacaoDoutorado;
    }

    public void setOrientacaoDoutorado(String orientacaoDoutorado) {
        this.orientacaoDoutorado = orientacaoDoutorado;
    }

    public String getBancaExame() {
        return bancaExame;
    }

    public void setBancaExame(String bancaExame) {
        this.bancaExame = bancaExame;
    }

    public String getBancaExameSelecao() {
        return bancaExameSelecao;
    }

    public void setBancaExameSelecao(String bancaExameSelecao) {
        this.bancaExameSelecao = bancaExameSelecao;
    }

    public String getCoordProjetos() {
        return coordProjetos;
    }

    public void setCoordProjetos(String coordProjetos) {
        this.coordProjetos = coordProjetos;
    }

    public String getPosDoutorado() {
        return posDoutorado;
    }

    public void setPosDoutorado(String posDoutorado) {
        this.posDoutorado = posDoutorado;
    }

    public String getPremios() {
        return premios;
    }

    public void setPremios(String premios) {
        this.premios = premios;
    }

    public String getTradLivro() {
        return tradLivro;
    }

    public void setTradLivro(String tradLivro) {
        this.tradLivro = tradLivro;
    }

    public String getPartOrg() {
        return partOrg;
    }

    public void setPartOrg(String partOrg) {
        this.partOrg = partOrg;
    }
    
    
}
