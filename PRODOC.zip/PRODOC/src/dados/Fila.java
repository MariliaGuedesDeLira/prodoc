package dados;

import dominio.Professor;

public class Fila {
	private Professor cadastro[];
	private int contador;
	private int tamanho;
	
	public Fila(int tamanho) {
		contador = 0;
		this.tamanho = tamanho;
		cadastro = new Professor[tamanho];
	}
	
	public Professor[] getCadastro() {
		return cadastro;
	}
	public void setCadastro(Professor[] cadastro) {
		this.cadastro = cadastro;
	}
	public int getContador() {
		return contador;
	}
	public void setContador(int contador) {
		this.contador = contador;
	}
	public int getTamanho() {
		return tamanho;
	}
	public void setTamanho(int tamanho) {
		this.tamanho = tamanho;
	}
	
	public int incluir(Professor professor) {
            int retorno = 0;
            
            if(contador < tamanho) { // Tem espa�o no cadastro
                    if(buscar(professor.getMatricula()) == -1) { // Matr�cula n�o existe no cadastro
                            cadastro[contador] = professor;
                            contador++;
                            retorno = 0; // Tudo OK
                    } else {
                        retorno = 2; // Aluno já existe
                    }
            } else {
                retorno = 1; // Fila cheia
            }
            return retorno;
	}
	
	public int buscar(int matricula) {
		int retorno = -1;
		
		for(int i = 0; i < contador; i++) {
			if(matricula == cadastro[i].getMatricula()) {
				retorno = i;
				break;
			}
		}
				
		return retorno;
	}
  
	
	public Professor consultar(int matricula) {
		Professor retorno = null;
		int resultado;
		
		resultado = buscar(matricula);
		
		if (resultado > -1) { // Achei
			retorno = cadastro[resultado];
		}
		
		return retorno;
	}
	
	public Professor alterar(Professor professor) {
		Professor retorno = null;
		int resultado;
		
		resultado = buscar(professor.getMatricula());
		
		if (resultado > -1) { // Achei
			cadastro[resultado] = professor;
			retorno = cadastro[resultado];
		}
		return retorno;
	}
	
	public Professor excluir () {
		Professor resultado = null;
		
		if (contador > 0) {
                    resultado = cadastro[0];
                    for (int i = 0; i < contador -1; i++){
                        cadastro[i] = cadastro [i+1];
                    }
			contador--;
		}
                return resultado;
	}
        
        public boolean validaMatricula(int matricula){
        
            int retorno = -1;
		
		for(int i = 0; i < contador; i++) {
			if(matricula == cadastro[i].getMatricula()) {
				retorno = i;
                                return false;
				
			}
		}
				
		return true;
        
        }
}